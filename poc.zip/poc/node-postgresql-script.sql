


CREATE TABLE ac_cluster.realtimedata(
id SERIAL NOT NULL PRIMARY KEY,
username character varying(50) not null,
userdata text not null,
infosource character varying(50)
);

CREATE FUNCTION ac_cluster.notify_realtimedata() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM pg_notify('addednew', NEW.userdata);
    RETURN NULL;
END;
$$;

CREATE TRIGGER updated_realtime_trigger AFTER INSERT ON ac_cluster.realtimedata
FOR EACH ROW EXECUTE PROCEDURE ac_cluster.notify_realtimedata();


INSERT INTO ac_cluster.realtimedata values(1,'Demo', 'Client sends the Server a handshake request in the form of a HTTP upgrade header with data', 'Manual');

INSERT INTO ac_cluster.realtimedata values(2,'User1', 'The Server responds to the request with another HTTP header, this is the last time a HTTP header gets used in the WebSocket connection.', 'Manual');

INSERT INTO ac_cluster.realtimedata values(3,'User2', 'If the handshake was successful, they server sends a HTTP header telling the client it’s switching to the WebSocket protocol.', 'Manual');

INSERT INTO ac_cluster.realtimedata values(4,'User3', 'Now a constant connection is opened and the client and server can send any number of messages to each other until the connection is closed.', 'Manual');

INSERT INTO ac_cluster.realtimedata values(5,'User4', 'These messages only have about 2 bytes of overhead.', 'Manual');

INSERT INTO ac_cluster.realtimedata values(6,'User5', 'Vijay Mamidi', 'Manual');


DROP table ac_cluster.realtimedata
DROP TRIGGER updated_realtime_trigger ON ac_cluster.realtimedata;
DROP FUNCTION ac_cluster.notify_realtimedata();

DELETE FROM ac_cluster.realtimedata