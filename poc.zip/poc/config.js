module.exports = {
    // PostgreSQL SETTINGS
   "host": process.env.DBHOST || 'VMAMIDI55TSPC2.opentext.net',
   "port": process.env.DBPORT || '8433',
   "database": process.env.DATABASE || 'ihub'
}; 