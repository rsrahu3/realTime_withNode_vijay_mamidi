const express = require('express');
const url = require('url');
const WebSocket = require('ws');
const app = express();
const pg = require('pg');
const http = require('http');
const path = require('path');
const fs = require('fs');
var config = require('./config.js');

exports.currentDir = path.dirname(__filename);	
exports.filesDir = path.join(exports.currentDir, '../', 'files');
var filedata = fs.readFileSync(exports.filesDir+'/TestData.txt', 'utf-8')

http.globalAgent.keepAlive = true

// pg
var conString = "postgres://postgres:postgres@" +config.host+":"+config.port+"/"+config.database;
var pg_client = new pg.Client(conString);
pg_client.connect();
var query = pg_client.query('LISTEN addednew');


app.use(function (req, res) { 
    console.log((new Date()) + ' Received request for ' + request.url);
	res.writeHead(200, {
        "Content-Type": "text/html",
        "Cache-Control": "no-cache",
        "Access-Control-Allow-Origin": "*",
        "Connection": "keep-alive"
    });    
});
 
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

var counter = 0; 
wss.on('connection', function connection(ws, req) {
  const location = url.parse(req.url, true);
  console.log('location: %s', req.url);
  
  ws.on('message', function incoming(message) {
    console.log((new Date()) + ' received @server: %s', message);
	    
      if (ws.readyState === WebSocket.OPEN) {
		 var userdataout; 
		pg_client.on('notification', function(userdata) {
			console.log(JSON.stringify({ 'message': userdata }));
			userdataout = userdata;		
				
		});	
			
		 function sendData(){
			var number = Math.round(Math.random() * 10000);
				counter = parseInt(counter + 1);			
			
			var obj = { "dynanumber" : number,
					"counter" : counter,
					"filedata" : filedata,
					"message": userdataout 
				};		
			var jsonStr = JSON.stringify(obj);
			if (ws.readyState === WebSocket.OPEN) {
				ws.send(jsonStr);
				setTimeout(sendData, 1000);  
			}	
			
		  }
		sendData();			  
      }  
  });   
});
 
server.listen(9000, function listening(req, res) {
  console.log((new Date()) + 'Listening on %d', server.address().port);
});
